# 仿饿了么购物车效果

* 左右侧列表联动
* 顶部吸附标题
* 利用二次贝塞尔曲线做成下单特效等

<img src="/picture/picture1.png?raw=true" width=360 height=640 alt="Quick Demo">
<img src="/picture/picture2.png?raw=true" width=360 height=640 alt="Quick Demo">
<img src="/picture/gif1.gif?raw=true" width=360 height=640 alt="horizontal_and_vertical_flip">