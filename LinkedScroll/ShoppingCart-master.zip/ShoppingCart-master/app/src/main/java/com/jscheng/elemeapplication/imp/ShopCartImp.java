package com.jscheng.elemeapplication.imp;

import android.view.View;

/**
 * Created by cheng on 16-11-13.
 */
public interface ShopCartImp {
    void add(View view, int postion);
    void remove(View view, int postion);
}
