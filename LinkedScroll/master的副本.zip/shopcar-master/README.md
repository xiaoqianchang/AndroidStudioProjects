# 仿饿了么购物车下单效果
###效果如图：
![image](https://raw.githubusercontent.com/917386389/shopcar/master/screenshot/1.gif)
###仿外卖下单,项目可直接引用，欢迎star、fork、如有问题请提issues

